var app = angular.module('Data', ['firebase']);

